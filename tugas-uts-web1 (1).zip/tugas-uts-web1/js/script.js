/* ====== Helper ====== */
const rupiah = n => "Rp " + Number(n).toLocaleString("id-ID");
const $ = id => document.getElementById(id);
const halaman = document.body.dataset.page;

function bukaModal(id) { $(id).classList.add("tampil"); }
function tutupModal(id) { $(id).classList.remove("tampil"); }
document.addEventListener("click", e => {
  if (e.target.classList.contains("modal")) e.target.classList.remove("tampil");
  if (e.target.dataset.tutup) tutupModal(e.target.dataset.tutup);
});

function ambilRiwayat() { return JSON.parse(localStorage.getItem("riwayatPesanan") || "[]"); }
function simpanRiwayat(r) { localStorage.setItem("riwayatPesanan", JSON.stringify(r)); }
function userAktif() { return JSON.parse(sessionStorage.getItem("userAktif") || "null"); }

/* ====== Proteksi halaman (selain login) ====== */
if (halaman !== "login" && !userAktif()) location.href = "index.html";
function logout() { sessionStorage.removeItem("userAktif"); location.href = "index.html"; }

/* ====== 1. LOGIN ====== */
if (halaman === "login") {
  $("formLogin").addEventListener("submit", e => {
    e.preventDefault();
    const email = $("email").value.trim().toLowerCase();
    const pass = $("password").value;
    const user = dataUser.find(u => u.email === email && u.password === pass);
    if (!user) { alert("email/password yang anda masukkan salah"); return; }
    sessionStorage.setItem("userAktif", JSON.stringify(user));
    location.href = "dashboard.html";
  });
  $("btnLupa").onclick = () => bukaModal("modalLupa");
  $("btnDaftar").onclick = () => bukaModal("modalDaftar");
  $("formLupa").addEventListener("submit", e => {
    e.preventDefault();
    alert("Tautan reset password dikirim ke " + $("emailLupa").value);
    tutupModal("modalLupa");
  });
  $("formDaftar").addEventListener("submit", e => {
    e.preventDefault();
    const email = $("emailDaftar").value.trim().toLowerCase();
    if (dataUser.some(u => u.email === email)) { alert("Email sudah terdaftar."); return; }
    dataUser.push({ email, password: $("passDaftar").value, nama: $("namaDaftar").value });
    alert("Pendaftaran berhasil. Silakan login (berlaku selama halaman ini terbuka).");
    tutupModal("modalDaftar");
  });
}

/* ====== 2. DASHBOARD ====== */
if (halaman === "dashboard") {
  const jam = new Date().getHours();
  let sapaan = "Selamat malam";
  if (jam >= 4 && jam < 11) sapaan = "Selamat pagi";
  else if (jam >= 11 && jam < 15) sapaan = "Selamat siang";
  else if (jam >= 15 && jam < 18) sapaan = "Selamat sore";
  $("greeting").textContent = sapaan + ", " + userAktif().nama;
  $("jamLokal").textContent = new Date().toLocaleString("id-ID", { dateStyle: "full", timeStyle: "short" });

  $("btnLaporan").onclick = () => {
    const r = ambilRiwayat();
    const totalOmzet = r.reduce((s, x) => s + x.total, 0);
    $("isiLaporan").innerHTML = r.length
      ? `<p>Jumlah pesanan: <b>${r.length}</b> &nbsp; Total nilai: <b>${rupiah(totalOmzet)}</b></p>
         <table><tr><th>No. DO</th><th>Pemesan</th><th>Item</th><th>Total</th></tr>
         ${r.map(x => `<tr><td>${x.noDO}</td><td>${x.nama}</td><td>${x.item.reduce((s, i) => s + i.qty, 0)}</td><td>${rupiah(x.total)}</td></tr>`).join("")}</table>`
      : `<p class="kosong">Belum ada pesanan. Buat pesanan di halaman Pemesanan.</p>`;
    bukaModal("modalLaporan");
  };
  $("btnHistory").onclick = () => {
    const r = ambilRiwayat().slice().reverse();
    $("isiHistory").innerHTML = r.length
      ? `<table><tr><th>Tanggal</th><th>No. DO</th><th>Pembayaran</th><th>Total</th></tr>
         ${r.map(x => `<tr><td>${x.tanggal}</td><td>${x.noDO}</td><td>${x.bayar}</td><td>${rupiah(x.total)}</td></tr>`).join("")}</table>`
      : `<p class="kosong">Belum ada transaksi.</p>`;
    bukaModal("modalHistory");
  };
}

/* ====== 3. STOK / KATALOG ====== */
if (halaman === "stok") {
  const tbody = $("tbodyStok");
  function tambahBaris(b) {
    const tr = document.createElement("tr");
    const status = b.stok === 0 ? '<span class="lencana habis">Habis</span>' : b.stok < 10 ? '<span class="lencana tipis">Menipis</span>' : '<span class="lencana ada">Tersedia</span>';
    tr.innerHTML = `<td>${b.kode}</td><td><b>${b.judul}</b><br><small>${b.penulis}</small></td><td>${b.kategori}</td>
                    <td>${rupiah(b.harga)}</td><td>${b.stok}</td><td>${status}</td>
                    <td><button class="btn kecil hapus">Hapus</button></td>`;
    tr.querySelector(".hapus").onclick = () => tr.remove();
    tbody.appendChild(tr);
  }
  dataKatalogBuku.forEach(tambahBaris);

  $("formStok").addEventListener("submit", e => {
    e.preventDefault();
    const b = {
      kode: $("kode").value.trim(), judul: $("judul").value.trim(), penulis: $("penulis").value.trim(),
      kategori: $("kategori").value, harga: Number($("harga").value), stok: Number($("stokBaru").value)
    };
    tambahBaris(b); // DOM: menambah baris stok baru
    e.target.reset();
  });
}

/* ====== 4. CHECKOUT ====== */
if (halaman === "checkout") {
  let keranjang = dataPesananAwal.map(p => ({ ...p }));
  const cari = kode => dataKatalogBuku.find(b => b.kode === kode);
  $("pilihBuku").innerHTML = dataKatalogBuku.filter(b => b.stok > 0)
    .map(b => `<option value="${b.kode}">${b.judul} - ${rupiah(b.harga)}</option>`).join("");

  function render() {
    const tbody = $("tbodyPesanan");
    tbody.innerHTML = "";
    let total = 0;
    keranjang.forEach((p, i) => {
      const b = cari(p.kode); const sub = b.harga * p.qty; total += sub;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${b.judul}</td><td>${rupiah(b.harga)}</td>
        <td><input type="number" min="1" max="${b.stok}" value="${p.qty}" class="qty" aria-label="Jumlah ${b.judul}"></td>
        <td>${rupiah(sub)}</td><td><button class="btn kecil hapus">Hapus</button></td>`;
      tr.querySelector(".qty").onchange = e => { p.qty = Math.max(1, Math.min(b.stok, Number(e.target.value) || 1)); render(); };
      tr.querySelector(".hapus").onclick = () => { keranjang.splice(i, 1); render(); };
      tbody.appendChild(tr);
    });
    if (!keranjang.length) tbody.innerHTML = '<tr><td colspan="5" class="kosong">Pesanan kosong. Tambahkan buku di atas.</td></tr>';
    $("totalBayar").textContent = rupiah(total);
  }
  $("btnTambah").onclick = () => {
    const kode = $("pilihBuku").value;
    const ada = keranjang.find(p => p.kode === kode);
    if (ada) ada.qty++; else keranjang.push({ kode, qty: 1 });
    render();
  };
  $("formCheckout").addEventListener("submit", e => {
    e.preventDefault();
    if (!keranjang.length) { alert("Pesanan masih kosong."); return; }
    const total = keranjang.reduce((s, p) => s + cari(p.kode).harga * p.qty, 0);
    const noDO = "DO" + Date.now().toString().slice(-8);
    const pesanan = {
      noDO, nama: $("nama").value, alamat: $("alamat").value, telp: $("telp").value,
      bayar: $("bayar").value, tanggal: new Date().toLocaleDateString("id-ID"),
      item: keranjang.map(p => ({ ...p })), total
    };
    const r = ambilRiwayat(); r.push(pesanan); simpanRiwayat(r);
    alert("Pesanan berhasil dibuat!\nNomor Delivery Order: " + noDO + "\nSimpan nomor ini untuk melacak pengiriman.");
    keranjang = []; e.target.reset(); render();
  });
  render();
}

/* ====== 5. TRACKING ====== */
if (halaman === "tracking") {
  $("formTrack").addEventListener("submit", e => {
    e.preventDefault();
    const no = $("noDO").value.trim().toUpperCase();
    let d = dataTracking.find(x => x.noDO === no);
    if (!d) { // cek pesanan yang dibuat di halaman checkout
      const p = ambilRiwayat().find(x => x.noDO === no);
      if (p) d = { noDO: p.noDO, nama: p.nama, status: 0, ekspedisi: "JNE Reguler", tanggalKirim: new Date().toISOString().slice(0, 10),
                   jenisPaket: `Paket Buku (${p.item.reduce((s, i) => s + i.qty, 0)} item)`, total: p.total };
    }
    const hasil = $("hasil");
    if (!d) { hasil.innerHTML = '<p class="kosong">Nomor Delivery Order tidak ditemukan. Periksa kembali nomornya.</p>'; return; }
    const persen = ((d.status + 1) / daftarStatus.length) * 100;
    hasil.innerHTML = `
      <h2>${d.nama}</h2>
      <div class="progres"><div class="isi" style="width:${persen}%"></div></div>
      <ol class="langkah">${daftarStatus.map((s, i) => `<li class="${i <= d.status ? "selesai" : ""}">${s}</li>`).join("")}</ol>
      <p>Status: <b>${daftarStatus[d.status]}</b></p>
      <table>
        <tr><th>No. Delivery Order</th><td>${d.noDO}</td></tr>
        <tr><th>Ekspedisi</th><td>${d.ekspedisi}</td></tr>
        <tr><th>Tanggal kirim</th><td>${new Date(d.tanggalKirim).toLocaleDateString("id-ID", { dateStyle: "long" })}</td></tr>
        <tr><th>Jenis paket</th><td>${d.jenisPaket}</td></tr>
        <tr><th>Total pembayaran</th><td>${rupiah(d.total)}</td></tr>
      </table>`;
  });
}
