// Data dummy (pengganti server/database) - format Array JSON
const dataUser = [
  { email: "mahasiswa@email.com", password: "123456", nama: "Syafira" },
  { email: "admin@tokobuku.com", password: "admin123", nama: "Admin" }
];

const dataKatalogBuku = [
  { kode: "BK001", judul: "Pemrograman Web Dasar", penulis: "Andi Wijaya", kategori: "Teknologi", harga: 85000, stok: 24 },
  { kode: "BK002", judul: "Belajar JavaScript Modern", penulis: "Rina Kartika", kategori: "Teknologi", harga: 98000, stok: 15 },
  { kode: "BK003", judul: "Laskar Pelangi", penulis: "Andrea Hirata", kategori: "Novel", harga: 75000, stok: 30 },
  { kode: "BK004", judul: "Bumi Manusia", penulis: "Pramoedya A. Toer", kategori: "Novel", harga: 110000, stok: 8 },
  { kode: "BK005", judul: "Atomic Habits (Terjemahan)", penulis: "James Clear", kategori: "Pengembangan Diri", harga: 99000, stok: 18 },
  { kode: "BK006", judul: "Fiqh Ibadah Praktis", penulis: "Tim Penulis PAI", kategori: "Agama", harga: 65000, stok: 0 }
];

// Status pengiriman berurutan (index dipakai untuk progress bar)
const daftarStatus = ["Diproses", "Dikemas", "Dikirim", "Diterima"];

const dataTracking = [
  { noDO: "DO2026001", nama: "Budi Santoso", status: 2, ekspedisi: "JNE Reguler", tanggalKirim: "2026-11-05", jenisPaket: "Paket Buku (2 item)", total: 183000 },
  { noDO: "DO2026002", nama: "Siti Aminah", status: 3, ekspedisi: "SiCepat Halu", tanggalKirim: "2026-11-01", jenisPaket: "Paket Buku (1 item)", total: 75000 },
  { noDO: "DO2026003", nama: "Rahmat Hidayat", status: 0, ekspedisi: "J&T Express", tanggalKirim: "2026-11-07", jenisPaket: "Paket Buku (3 item)", total: 292000 }
];

// Pesanan awal untuk halaman checkout (bisa ditambah/ubah)
const dataPesananAwal = [
  { kode: "BK001", qty: 1 },
  { kode: "BK003", qty: 2 }
];
